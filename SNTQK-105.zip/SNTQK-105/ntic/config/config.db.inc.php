<?php

$cfg["db-hostname"] = "";
$cfg["db-database"] = "";
$cfg["db-username"] = "";
$cfg["db-password"] = "";
$cfg["db-tbl-prefix"] = "";

?>