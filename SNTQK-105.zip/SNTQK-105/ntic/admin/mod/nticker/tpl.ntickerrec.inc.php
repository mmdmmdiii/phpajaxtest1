<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// AjaxNewsTicker v1.05
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : SNTQK-105
// URL : http://www.phpkobo.com/ajax-news-ticker
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<
?>
<div class="ntickerrec-ctar">
	<div class="ntickerrec-menu">
	<?php include("tpl.ntickerrec.menu.inc.php"); ?>
	</div>
	<div class="ntickerrec-content">
		<div class="ntickerrec-tab-content ntickerrec-tab-content-settings">
			<?php include("tpl.ntickerrec.tab.settings.inc.php"); ?>
		</div>

		<div class="ntickerrec-tab-content ntickerrec-tab-content-preview">
			<?php include("tpl.ntickerrec.tab.preview.inc.php"); ?>
		</div>
	</div>
</div>
<?php // ?>