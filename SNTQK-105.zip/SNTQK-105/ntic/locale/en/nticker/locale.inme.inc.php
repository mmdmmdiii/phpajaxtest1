<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// AjaxNewsTicker v1.05
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : SNTQK-105
// URL : http://www.phpkobo.com/ajax-news-ticker
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

$lca["action"] = "Select";

$lca["title:scripttag"] = "Script Tag";

$lca["text:put-line-html"] = "Put the following line of code in your webpage where you want the news ticker to appear.";
$lca["label:copy-to-clip"] = "<span class='glyphicon glyphicon-copy'></span> Copy to clipboard";
$lca["label:run-preview"] = "<span class='glyphicon glyphicon-new-window'></span> Preview in a new tab";

?>