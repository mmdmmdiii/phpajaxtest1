<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// AjaxNewsTicker v1.05
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : SNTQK-105
// URL : http://www.phpkobo.com/ajax-news-ticker
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

$lca["inst-success"] = "The installation has been done successfully!";
$lca["important-title"] = "IMPORTANT!";
$lca["important-message"] = "Please remove <b>install</b> folder " .
	"from your web site to avoid a security risk!";

$lca["log-in-to-admin"] = "After removing the install folder, log in to " . 
	"<a class='link' href='%url-admin%' target='_blank'>" .
	"%app-name% admin panel</a> using the username and password shown below.";
$lca["username"] = "Username";
$lca["password"] = "Password";

?>